package Controlador;

import Vista.interfaz_menu;
import Vista.Formulario_Busqueda;
import Vista.Formulario_Residentes;
import Vista.Formulario_Alicuotas;
import Vista.interfaz_busqueda;
import Vista.interfaz_residentes;
import Vista.interfaz_alicuotas;

public class controlador_menu {

    private final interfaz_menu vista;

    public controlador_menu(interfaz_menu vista) {
        this.vista = vista;

        this.vista.getButtonResidentes().addActionListener(e -> irRegistroResidentes());
        this.vista.getBtnBusqueda().addActionListener(e -> mostrarBusqueda());
        this.vista.getBtnAlicuotas().addActionListener(e -> irRegistroAlicuotas());
    }

    public void irRegistroResidentes() {
        interfaz_residentes vistaR = new Formulario_Residentes();
        controlador_residentes ctrlR = new controlador_residentes(vistaR);
        ctrlR.iniciar();
        ((javax.swing.JFrame) this.vista).dispose();
    }

    public void mostrarBusqueda() {
        interfaz_busqueda vistaB = new Formulario_Busqueda();
        controlador_busqueda ctrlB = new controlador_busqueda(vistaB);
        ctrlB.iniciar();
        ((javax.swing.JFrame) this.vista).dispose();
    }

    public void irRegistroAlicuotas() {
        interfaz_alicuotas vistaA = new Formulario_Alicuotas();
        controlador_alicuotas ctrlA = new controlador_alicuotas(vistaA);
        ctrlA.iniciar();
        ((javax.swing.JFrame) this.vista).dispose();
    }

    public void abrirMenu() {
        vista.mostrarMenu();
    }
}
