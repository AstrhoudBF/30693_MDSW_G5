package Modelo;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import org.bson.Document;

public class AlmacenarAlicuotas {

    private final MongoCollection<Document> coleccion;

    public AlmacenarAlicuotas() {
        MongoDatabase bdd = Conectar_Mongo.getConec();
        this.coleccion = bdd.getCollection("Alicuotas");
    }

    // ── Convierte Alicuota → Document para MongoDB ────────────────
    private Document toDocument(Alicuota a) {
        // Convertir LocalDateTime a Date (lo que MongoDB acepta)
        Date fecha = Date.from(
            a.getFechaRegistro().atZone(ZoneId.systemDefault()).toInstant()
        );
        return new Document("NumeroCasa",      a.getNumeroCasa())
                .append("NombreResidente", a.getNombreResidente())
                .append("Monto",           a.getMonto())
                .append("Periodo",         a.getPeriodo())
                .append("Estado",          a.getEstado())
                .append("FormaPago",       a.getFormaPago())
                .append("FechaRegistro",   fecha);
    }

    // ── Convierte Document → Alicuota ─────────────────────────────
    private Alicuota fromDocument(Document d) {
        Alicuota a = new Alicuota();
        a.setId(d.getObjectId("_id").toHexString());
        a.setNumeroCasa(d.getString("NumeroCasa"));
        a.setNombreResidente(d.getString("NombreResidente"));
        a.setMonto(d.getDouble("Monto") != null ? d.getDouble("Monto") : 0.0);
        a.setPeriodo(d.getString("Periodo"));
        a.setEstado(d.getString("Estado"));
        a.setFormaPago(d.getString("FormaPago"));

        Date fecha = d.getDate("FechaRegistro");
        if (fecha != null) {
            a.setFechaRegistro(
                fecha.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime()
            );
        }
        return a;
    }

    // ── Insertar una alícuota nueva ───────────────────────────────
    public void guardar(Alicuota a) {
        coleccion.insertOne(toDocument(a));
    }

    // ── Obtener todas las alícuotas ───────────────────────────────
    public ArrayList<Alicuota> obtenerTodas() {
        ArrayList<Alicuota> lista = new ArrayList<>();
        for (Document d : coleccion.find()) {
            lista.add(fromDocument(d));
        }
        return lista;
    }

    // ── Buscar el residente asignado a un número de casa ──────────
    // Consulta la colección "Residentes" y devuelve "Nombres Apellidos"
    public String obtenerResidentePorCasa(String numeroCasa) {
        MongoDatabase bdd = Conectar_Mongo.getConec();
        MongoCollection<Document> residentes = bdd.getCollection("Residentes");

        Document filtro = new Document("NumeroVivienda", numeroCasa);
        Document encontrado = residentes.find(filtro).first();

        if (encontrado != null) {
            String nombres   = encontrado.getString("Nombres");
            String apellidos = encontrado.getString("Apellidos");
            return (nombres != null ? nombres : "") + " " + (apellidos != null ? apellidos : "");
        }
        return null;  // casa sin residente asignado
    }
}
