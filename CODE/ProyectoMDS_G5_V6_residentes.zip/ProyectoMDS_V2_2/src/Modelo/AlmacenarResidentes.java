package Modelo;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import java.util.ArrayList;
import java.util.List;
import org.bson.Document;

public class AlmacenarResidentes {

    public static MongoCollection<Document> columnas;

    public AlmacenarResidentes() {
        MongoDatabase bdd = Conectar_Mongo.getConec();
        this.columnas = bdd.getCollection("Residentes");
    }

    // ── Residentes → Document ─────────────────────────────────────
    private Document agregarDoc(Residentes r) {
        // Serializar vehículos como lista de documentos {Placa, TipoVehiculo}
        List<Document> vDocs = new ArrayList<>();
        if (r.getVehiculos() != null) {
            for (String[] v : r.getVehiculos()) {
                vDocs.add(new Document("Placa", v[0]).append("TipoVehiculo", v[1]));
            }
        }
        return new Document("Nombres",              r.getNombres())
                .append("Apellidos",             r.getApellidos())
                .append("Cedula",                r.getCedula())
                .append("TelefonoMovil",         r.getTelefonoMovil())
                .append("TelefonoConvencional",  r.getTelefonoConvencional() != null ? r.getTelefonoConvencional() : "")
                .append("NumeroVivienda",        r.getNumeroVivienda())
                .append("TipoResidente",         r.getTipoResidente())
                .append("TieneMascotas",         r.isTieneMascotas())
                .append("Vehiculos",             vDocs);
    }

    // ── Document → Residentes ─────────────────────────────────────
    @SuppressWarnings("unchecked")
    private Residentes sacarDocumento(Document d) {
        // Deserializar vehículos
        List<String[]> vehiculos = new ArrayList<>();
        List<Document> vDocs = (List<Document>) d.get("Vehiculos");
        if (vDocs != null) {
            for (Document v : vDocs) {
                vehiculos.add(new String[]{
                    v.getString("Placa") != null    ? v.getString("Placa")        : "",
                    v.getString("TipoVehiculo") != null ? v.getString("TipoVehiculo") : ""
                });
            }
        }
        return new Residentes(
                d.getString("Nombres"),
                d.getString("Apellidos"),
                d.getString("Cedula"),
                d.getString("TelefonoMovil"),
                d.getString("TelefonoConvencional"),
                d.getString("NumeroVivienda"),
                d.getString("TipoResidente"),
                Boolean.TRUE.equals(d.getBoolean("TieneMascotas")),
                vehiculos
        );
    }

    public ArrayList<Residentes> obtenerTodos() {
        ArrayList<Residentes> lista = new ArrayList<>();
        for (Document d : columnas.find()) {
            lista.add(sacarDocumento(d));
        }
        return lista;
    }

    public void agregarMongo(Residentes r) {
        columnas.insertOne(agregarDoc(r));
    }

    // Compatibilidad con código legacy
    public final List<Residentes> lista = new ArrayList<>();
    public void guardar(Residentes r)   { lista.add(r); }
    public List<Residentes> listar()    { return lista; }
}
