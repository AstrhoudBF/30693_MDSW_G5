package Controlador;

import Modelo.Alicuota;
import Modelo.AlmacenarAlicuotas;
import Vista.interfaz_alicuotas;
import java.time.LocalDateTime;
import java.util.ArrayList;

public class controlador_alicuotas {

    private final interfaz_alicuotas vista;
    private final AlmacenarAlicuotas repo;
    private final ArrayList<Alicuota> listaLocal = new ArrayList<>();

    public controlador_alicuotas(interfaz_alicuotas vista) {
        this.vista = vista;
        this.repo  = new AlmacenarAlicuotas();

        listaLocal.addAll(repo.obtenerTodas());
        vista.actualizarTabla(listaLocal);

        vista.getComboCasa().addActionListener(e -> buscarResidente());
        vista.getBtnGuardar().addActionListener(e -> guardar());
        vista.getBtnRegresar().addActionListener(e -> regresar());
    }

    private void buscarResidente() {
        String casa = vista.getNumeroCasa();
        if (casa == null || casa.trim().isEmpty() || casa.equals("-- Seleccione --")) {
            vista.setNombreResidente("");
            return;
        }
        String residente = repo.obtenerResidentePorCasa(casa.trim());
        vista.setNombreResidente(
            (residente != null && !residente.trim().isEmpty())
                ? residente.trim()
                : "Sin residente asignado"
        );
    }

    private void guardar() {
        try {
            String casa = vista.getNumeroCasa();
            if (casa == null || casa.trim().isEmpty() || casa.equals("-- Seleccione --")) {
                vista.mostrarMensaje("Debe seleccionar un número de casa."); return;
            }
            String residente = vista.getNombreResidente();
            if (residente == null || residente.trim().isEmpty()
                    || residente.equals("Sin residente asignado")) {
                vista.mostrarMensaje("La casa seleccionada no tiene un residente asignado."); return;
            }

            double monto;
            try {
                monto = vista.getMonto();
                if (monto <= 0) { vista.mostrarMensaje("El monto debe ser mayor a cero."); return; }
            } catch (NumberFormatException ex) {
                vista.mostrarMensaje("El monto ingresado no es válido."); return;
            }

            String periodo = vista.getPeriodo();
            if (periodo == null || periodo.trim().isEmpty()) {
                vista.mostrarMensaje("Debe ingresar el período (ej: Junio 2026)."); return;
            }

            // ── Cruce con multas pendientes ────────────────────────
            String aviso = repo.generarAvisoMultas(casa.trim());
            if (aviso != null) {
                javax.swing.JOptionPane.showMessageDialog(
                    null, aviso,
                    "⚠ Multas pendientes del residente",
                    javax.swing.JOptionPane.WARNING_MESSAGE
                );
            }

            Alicuota a = new Alicuota(
                casa.trim(), residente.trim(), monto,
                periodo.trim(), vista.getEstado(), vista.getFormaPago(),
                LocalDateTime.now()
            );
            repo.guardar(a);
            listaLocal.add(a);
            vista.actualizarTabla(listaLocal);
            vista.mostrarMensaje("Alícuota registrada correctamente.");
            vista.limpiarCampos();

        } catch (Exception ex) {
            vista.mostrarMensaje("Error al guardar: " + ex.getMessage());
        }
    }

    private void regresar() {
        Vista.interfaz_menu vistaM = new Vista.Formulario_Menu();
        controlador_menu ctrlM = new controlador_menu(vistaM);
        ctrlM.abrirMenu();
        vista.dispose();
    }

    public void iniciar() { vista.iniciar(); }
}
