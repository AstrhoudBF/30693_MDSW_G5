package Controlador;

import Modelo.AlmacenarResidentes;
import Modelo.Residentes;
import Vista.Formulario_Editar_Residente;
import Vista.interfaz_busqueda;
import java.util.ArrayList;

public class controlador_busqueda {

    private final interfaz_busqueda    vista;
    private final AlmacenarResidentes  repo;
    private ArrayList<Residentes>      listaActual = new ArrayList<>();

    public controlador_busqueda(interfaz_busqueda vista) {
        this.vista = vista;
        this.repo  = new AlmacenarResidentes();

        vista.getBtnBusqueda().addActionListener(e  -> buscar());
        vista.getBtnRegreso().addActionListener(e   -> regresar());
        vista.getBtnModificar().addActionListener(e -> abrirEdicion());
        vista.getBtnEliminar().addActionListener(e  -> eliminar());
    }

    // ── Buscar ────────────────────────────────────────────────────
    private void buscar() {
        String criterio = vista.getComboCriterio().getSelectedItem().toString();
        String dato     = vista.getStrBusqueda().trim().toLowerCase();

        if (dato.isEmpty()) {
            vista.mostrarMensaje("Ingrese un dato para buscar.");
            return;
        }

        ArrayList<Residentes> todos = repo.obtenerTodos();
        ArrayList<Residentes> resultado = new ArrayList<>();

        for (Residentes r : todos) {
            switch (criterio) {
                case "Nombre":
                    String nombreCompleto = (r.getNombres() + " " + r.getApellidos()).toLowerCase();
                    if (nombreCompleto.contains(dato)) resultado.add(r);
                    break;
                case "Cedula":
                    if (r.getCedula() != null && r.getCedula().contains(dato)) resultado.add(r);
                    break;
                case "N° Casa":
                    if (r.getNumeroVivienda() != null && r.getNumeroVivienda().equalsIgnoreCase(dato))
                        resultado.add(r);
                    break;
            }
        }

        listaActual = resultado;
        vista.mostrarResultados(resultado);

        if (resultado.isEmpty()) {
            vista.mostrarMensaje("No se encontraron residentes con ese criterio.");
        }
    }

    // ── Abrir formulario de edición ───────────────────────────────
    private void abrirEdicion() {
        String cedula = vista.getCedulaSeleccionada();
        if (cedula == null) {
            vista.mostrarMensaje("Seleccione un residente de la tabla para modificar.");
            return;
        }

        // Encontrar el objeto completo en la lista actual
        Residentes seleccionado = null;
        for (Residentes r : listaActual) {
            if (cedula.equals(r.getCedula())) { seleccionado = r; break; }
        }
        if (seleccionado == null) {
            vista.mostrarMensaje("No se pudo obtener los datos del residente seleccionado.");
            return;
        }

        // Abrir formulario de edición con los datos cargados
        Formulario_Editar_Residente formEditar =
            new Formulario_Editar_Residente(seleccionado, cedula, this);
        formEditar.setVisible(true);
    }

    // ── Eliminar residente ────────────────────────────────────────
    private void eliminar() {
        String cedula = vista.getCedulaSeleccionada();
        if (cedula == null) {
            vista.mostrarMensaje("Seleccione un residente de la tabla para eliminar.");
            return;
        }

        // Obtener nombre para el mensaje de confirmación
        String nombre = "";
        for (Residentes r : listaActual) {
            if (cedula.equals(r.getCedula())) { nombre = r.getNombres() + " " + r.getApellidos(); break; }
        }

        int confirm = javax.swing.JOptionPane.showConfirmDialog(
            null,
            "¿Está seguro de eliminar al residente:\n" + nombre + "\nCédula: " + cedula + "?\n\nEsta acción no se puede deshacer.",
            "Confirmar eliminación",
            javax.swing.JOptionPane.YES_NO_OPTION,
            javax.swing.JOptionPane.WARNING_MESSAGE
        );

        if (confirm != javax.swing.JOptionPane.YES_OPTION) return;

        try {
            repo.eliminar(cedula);
            vista.mostrarMensaje("Residente eliminado correctamente.");
            // Refrescar búsqueda automáticamente
            buscar();
        } catch (Exception ex) {
            vista.mostrarMensaje("Error al eliminar: " + ex.getMessage());
        }
    }

    /** Llamado por Formulario_Editar_Residente al guardar cambios exitosamente */
    public void refrescarBusqueda() {
        buscar();
    }

    // ── Regresar al menú ──────────────────────────────────────────
    private void regresar() {
        Vista.interfaz_menu vistaM = new Vista.Formulario_Menu();
        controlador_menu ctrlM = new controlador_menu(vistaM);
        ctrlM.abrirMenu();
        vista.dispose();
    }

    public void iniciar() {
        vista.setVisible();
    }
}
