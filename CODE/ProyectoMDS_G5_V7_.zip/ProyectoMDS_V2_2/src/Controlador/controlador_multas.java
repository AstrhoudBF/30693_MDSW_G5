package Controlador;

import Modelo.AlmacenarMultas;
import Modelo.Multa;
import Vista.interfaz_multas;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;

public class controlador_multas {

    private final interfaz_multas   vista;
    private final AlmacenarMultas   repo;
    private ArrayList<Multa>        listaLocal = new ArrayList<>();

    // ID de la multa en edición (null = modo nuevo)
    private String idEnEdicion = null;

    public controlador_multas(interfaz_multas vista) {
        this.vista = vista;
        this.repo  = new AlmacenarMultas();

        listaLocal.addAll(repo.obtenerTodas());
        vista.actualizarTabla(listaLocal);

        // Autocompletar al cambiar la casa
        vista.getComboCasa().addActionListener(e -> autocompletarPorCasa());

        vista.getBtnGuardar().addActionListener(e   -> guardar());
        vista.getBtnModificar().addActionListener(e -> cargarParaEditar());
        vista.getBtnEliminar().addActionListener(e  -> eliminar());
        vista.getBtnRegresar().addActionListener(e  -> regresar());
    }

    // ── Autocompletar nombre y cédula al elegir casa ──────────────
    private void autocompletarPorCasa() {
        String casa = vista.getNumeroCasa();
        if (casa == null || casa.equals("-- Seleccione --") || casa.trim().isEmpty()) {
            vista.setNombreResidente("");
            vista.setCedulaResidente("");
            return;
        }
        String[] datos = repo.obtenerResidentePorCasa(casa.trim());
        if (datos != null) {
            vista.setNombreResidente(datos[0]);
            vista.setCedulaResidente(datos[1]);
        } else {
            vista.setNombreResidente("Sin residente asignado");
            vista.setCedulaResidente("");
        }
    }

    // ── Guardar (nuevo o actualización) ──────────────────────────
    private void guardar() {
        try {
            String casa = vista.getNumeroCasa();
            if (casa == null || casa.equals("-- Seleccione --") || casa.trim().isEmpty()) {
                vista.mostrarMensaje("Debe seleccionar el número de casa."); return;
            }
            String nombre = vista.getNombreResidente().trim();
            if (nombre.isEmpty() || nombre.equals("Sin residente asignado")) {
                vista.mostrarMensaje("La casa seleccionada no tiene un residente asignado."); return;
            }
            String motivo = vista.getMotivo().trim();
            if (motivo.isEmpty()) {
                vista.mostrarMensaje("Debe ingresar el motivo de la multa."); return;
            }
            LocalDate fechaInf = vista.getFechaInfraccion();
            if (fechaInf == null) {
                vista.mostrarMensaje("Debe seleccionar la fecha de infracción."); return;
            }
            double monto;
            try {
                monto = vista.getMonto();
                if (monto <= 0) { vista.mostrarMensaje("El monto debe ser mayor a cero."); return; }
            } catch (NumberFormatException ex) {
                vista.mostrarMensaje("El monto ingresado no es válido."); return;
            }

            Multa m = new Multa(
                casa.trim(),
                vista.getCedulaResidente().trim(),
                nombre,
                vista.getCategoria(),
                motivo,
                fechaInf,
                monto,
                vista.getEstado(),
                vista.getObservaciones().trim(),
                LocalDateTime.now()
            );

            if (idEnEdicion == null) {
                // ── NUEVO ──────────────────────────────────────────
                repo.guardar(m);
                vista.mostrarMensaje("Multa registrada correctamente.");
            } else {
                // ── ACTUALIZAR ─────────────────────────────────────
                repo.actualizar(idEnEdicion, m);
                idEnEdicion = null;
                vista.getBtnGuardar().setText("Guardar");
                vista.mostrarMensaje("Multa actualizada correctamente.");
            }

            refrescarLista();
            vista.limpiarCampos();

        } catch (Exception ex) {
            vista.mostrarMensaje("Error al guardar: " + ex.getMessage());
        }
    }

    // ── Cargar multa seleccionada en el formulario para editar ────
    private void cargarParaEditar() {
        String id = vista.getIdSeleccionado();
        if (id == null) {
            vista.mostrarMensaje("Seleccione una multa de la tabla para modificar."); return;
        }
        Multa seleccionada = buscarPorId(id);
        if (seleccionada == null) {
            vista.mostrarMensaje("No se pudo obtener los datos de la multa."); return;
        }
        // Poblar el formulario con los datos actuales
        vista.getComboCasa().setSelectedItem(seleccionada.getNumeroCasa());
        vista.setNombreResidente(seleccionada.getNombreResidente());
        vista.setCedulaResidente(seleccionada.getCedulaResidente());
        // Los demás campos son poblados por el formulario mediante getters de la interfaz;
        // la vista debe implementar setters adicionales o el formulario acepta estos datos.
        // Usamos el método especial que la vista expone para pre-cargar edición:
        if (vista instanceof Vista.Formulario_Multas) {
            ((Vista.Formulario_Multas) vista).precargarEdicion(seleccionada);
        }
        idEnEdicion = id;
        vista.getBtnGuardar().setText("Actualizar");
    }

    // ── Eliminar ──────────────────────────────────────────────────
    private void eliminar() {
        String id = vista.getIdSeleccionado();
        if (id == null) {
            vista.mostrarMensaje("Seleccione una multa de la tabla para eliminar."); return;
        }
        Multa seleccionada = buscarPorId(id);
        String desc = seleccionada != null
            ? seleccionada.getNombreResidente() + " — " + seleccionada.getMotivo()
            : id;

        int confirm = javax.swing.JOptionPane.showConfirmDialog(
            null,
            "¿Está seguro de eliminar la multa de:\n" + desc + "?\n\nEsta acción no se puede deshacer.",
            "Confirmar eliminación",
            javax.swing.JOptionPane.YES_NO_OPTION,
            javax.swing.JOptionPane.WARNING_MESSAGE
        );
        if (confirm != javax.swing.JOptionPane.YES_OPTION) return;

        try {
            repo.eliminar(id);
            refrescarLista();
            vista.mostrarMensaje("Multa eliminada correctamente.");
        } catch (Exception ex) {
            vista.mostrarMensaje("Error al eliminar: " + ex.getMessage());
        }
    }

    private Multa buscarPorId(String id) {
        for (Multa m : listaLocal) {
            if (id.equals(m.getId())) return m;
        }
        return null;
    }

    private void refrescarLista() {
        listaLocal = repo.obtenerTodas();
        vista.actualizarTabla(listaLocal);
    }

    private void regresar() {
        Vista.interfaz_menu vistaM = new Vista.Formulario_Menu();
        controlador_menu ctrlM = new controlador_menu(vistaM);
        ctrlM.abrirMenu();
        vista.dispose();
    }

    public void iniciar() { vista.iniciar(); }
}
