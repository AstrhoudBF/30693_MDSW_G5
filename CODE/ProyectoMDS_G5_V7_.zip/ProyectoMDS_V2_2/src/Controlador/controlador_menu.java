package Controlador;

import Vista.interfaz_menu;
import Vista.Formulario_Busqueda;
import Vista.Formulario_Residentes;
import Vista.Formulario_Alicuotas;
import Vista.Formulario_Multas;
import Vista.Dialogo_Selector_Arriendo;
import Vista.interfaz_busqueda;
import Vista.interfaz_residentes;
import Vista.interfaz_alicuotas;
import Vista.interfaz_multas;

public class controlador_menu {

    private final interfaz_menu vista;

    public controlador_menu(interfaz_menu vista) {
        this.vista = vista;
        this.vista.getButtonResidentes().addActionListener(e -> irRegistroResidentes());
        this.vista.getBtnBusqueda().addActionListener(e      -> mostrarBusqueda());
        this.vista.getBtnAlicuotas().addActionListener(e     -> irRegistroAlicuotas());
        this.vista.getBtnArriendos().addActionListener(e     -> irArriendos());
        this.vista.getBtnMultas().addActionListener(e        -> irMultas());
    }

    public void irRegistroResidentes() {
        interfaz_residentes vistaR = new Formulario_Residentes();
        new controlador_residentes(vistaR).iniciar();
        ((javax.swing.JFrame) this.vista).dispose();
    }

    public void mostrarBusqueda() {
        interfaz_busqueda vistaB = new Formulario_Busqueda();
        new controlador_busqueda(vistaB).iniciar();
        ((javax.swing.JFrame) this.vista).dispose();
    }

    public void irRegistroAlicuotas() {
        interfaz_alicuotas vistaA = new Formulario_Alicuotas();
        new controlador_alicuotas(vistaA).iniciar();
        ((javax.swing.JFrame) this.vista).dispose();
    }

    public void irArriendos() {
        Dialogo_Selector_Arriendo dlg =
            new Dialogo_Selector_Arriendo((javax.swing.JFrame) this.vista);
        dlg.setVisible(true);
    }

    public void irMultas() {
        interfaz_multas vistaM = new Formulario_Multas();
        new controlador_multas(vistaM).iniciar();
        ((javax.swing.JFrame) this.vista).dispose();
    }

    public void abrirMenu() {
        vista.mostrarMenu();
    }
}
