package Controlador;

import Modelo.Arriendo;
import Modelo.AlmacenarArriendos;
import Vista.interfaz_arriendos;
import java.time.LocalDateTime;
import java.util.ArrayList;

public class controlador_arriendos {

    private final interfaz_arriendos  vista;
    private final AlmacenarArriendos  repo;
    private final ArrayList<Arriendo> listaLocal = new ArrayList<>();

    public controlador_arriendos(interfaz_arriendos vista) {
        this.vista = vista;
        this.repo  = new AlmacenarArriendos();

        listaLocal.addAll(repo.obtenerTodos());
        vista.actualizarTabla(listaLocal);

        vista.getBtnGuardar().addActionListener(e  -> guardar());
        vista.getBtnRegresar().addActionListener(e -> regresar());
        vista.getBtnHistorial().addActionListener(e -> abrirHistorial());
    }

    // ── Guardar arriendo ──────────────────────────────────────────
    private void guardar() {
        try {
            String tipo = vista.getTipoEspacio();
            String espacio = vista.getNumeroEspacio().trim();
            if (espacio.isEmpty()) {
                vista.mostrarMensaje("Debe ingresar el número o nombre del espacio.");
                return;
            }
            String nombre = vista.getNombreArrendatario().trim();
            if (nombre.isEmpty()) {
                vista.mostrarMensaje("Debe ingresar el nombre del arrendatario.");
                return;
            }
            String contacto = vista.getContacto().trim();
            double monto;
            try {
                monto = vista.getMontoMensual();
                if (monto <= 0) { vista.mostrarMensaje("El monto debe ser mayor a cero."); return; }
            } catch (NumberFormatException ex) {
                vista.mostrarMensaje("El monto ingresado no es válido."); return;
            }
            String periodo = vista.getMesPeriodo().trim();
            if (periodo.isEmpty()) {
                vista.mostrarMensaje("Debe ingresar el mes/período (ej: Junio 2026)."); return;
            }

            Arriendo a = new Arriendo(
                tipo, espacio, nombre,
                vista.getTipoArrendatario(), contacto,
                monto, periodo,
                vista.getEstado(), vista.getFormaPago(),
                LocalDateTime.now()
            );
            repo.guardar(a);
            listaLocal.add(a);
            vista.actualizarTabla(listaLocal);
            vista.mostrarMensaje("Arriendo registrado correctamente.");
            vista.limpiarCampos();

        } catch (Exception ex) {
            vista.mostrarMensaje("Error al guardar: " + ex.getMessage());
        }
    }

    // ── Abrir historial / resumen ─────────────────────────────────
    private void abrirHistorial() {
        Vista.Formulario_Historial_Arriendos hist =
            new Vista.Formulario_Historial_Arriendos();
        hist.setVisible(true);
    }

    // ── Regresar al menú ──────────────────────────────────────────
    private void regresar() {
        Vista.interfaz_menu vistaM = new Vista.Formulario_Menu();
        controlador_menu ctrlM = new controlador_menu(vistaM);
        ctrlM.abrirMenu();
        vista.dispose();
    }

    public void iniciar() {
        vista.iniciar();
    }
}
