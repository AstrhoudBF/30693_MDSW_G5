package Vista;

import Controlador.controlador_alicuotas;
import Modelo.Alicuota;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class Formulario_Alicuotas extends javax.swing.JFrame implements interfaz_alicuotas {

    private DefaultTableModel modeloTabla;

    // ── Componentes ───────────────────────────────────────────────
    private JPanel pnlPrincipal;
    private JPanel pnlFormulario;
    private JPanel pnlTabla;

    private JLabel lblTitulo;
    private JLabel lblCasa;
    private JLabel lblResidente;
    private JLabel lblMonto;
    private JLabel lblPeriodo;
    private JLabel lblEstado;
    private JLabel lblFormaPago;

    private JComboBox<String> comboCasa;
    private JTextField txtResidente;
    private JTextField txtMonto;
    private JTextField txtPeriodo;
    private JComboBox<String> comboEstado;
    private JComboBox<String> comboFormaPago;

    private JButton btnGuardar;
    private JButton btnRegresar;

    private JTable tablaAlicuotas;
    private JScrollPane scrollTabla;

    public Formulario_Alicuotas() {
        initComponents();
        inicializarTabla();
    }

    // ── Construcción manual del UI ─────────────────────────────────
    private void initComponents() {
        setTitle("Registro de Alícuotas");
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setSize(780, 620);
        setLocationRelativeTo(null);
        setResizable(false);

        // Panel principal blanco
        pnlPrincipal = new JPanel(null);
        pnlPrincipal.setBackground(Color.WHITE);
        pnlPrincipal.setPreferredSize(new Dimension(780, 620));

        // ── Título ────────────────────────────────────────────────
        lblTitulo = new JLabel("Registro de Alícuotas");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblTitulo.setForeground(new Color(30, 30, 30));
        lblTitulo.setBounds(20, 15, 300, 30);
        pnlPrincipal.add(lblTitulo);

        // ── Panel del formulario ───────────────────────────────────
        pnlFormulario = new JPanel(null);
        pnlFormulario.setBackground(new Color(245, 245, 245));
        pnlFormulario.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)),
            "Datos de la Alícuota",
            javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION,
            javax.swing.border.TitledBorder.DEFAULT_POSITION,
            new Font("Segoe UI", Font.BOLD, 12)
        ));
        pnlFormulario.setBounds(15, 55, 745, 230);
        pnlPrincipal.add(pnlFormulario);

        int labelX = 15, fieldX = 175, rowH = 35, startY = 25;
        int labelW = 155, fieldW = 200, fieldH = 28;

        // Fila 1 — Casa
        lblCasa = makeLabel("N° de Casa:");
        lblCasa.setBounds(labelX, startY, labelW, fieldH);
        pnlFormulario.add(lblCasa);

        comboCasa = new JComboBox<>();
        comboCasa.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        comboCasa.addItem("-- Seleccione --");
        for (int i = 1; i <= 20; i++) comboCasa.addItem(String.valueOf(i));
        comboCasa.setBounds(fieldX, startY, 120, fieldH);
        pnlFormulario.add(comboCasa);

        // Fila 1 — Residente (autocompletado, read-only)
        JLabel lblResLbl = makeLabel("Residente:");
        lblResLbl.setBounds(330, startY, 120, fieldH);
        pnlFormulario.add(lblResLbl);

        txtResidente = new JTextField();
        txtResidente.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        txtResidente.setEditable(false);
        txtResidente.setBackground(new Color(230, 230, 230));
        txtResidente.setBounds(455, startY, 270, fieldH);
        pnlFormulario.add(txtResidente);

        // Fila 2 — Monto
        int y2 = startY + rowH;
        lblMonto = makeLabel("Monto ($):");
        lblMonto.setBounds(labelX, y2, labelW, fieldH);
        pnlFormulario.add(lblMonto);

        JTextField txtM = new JTextField();
        txtM.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        txtM.setName("txtMonto");
        txtM.setBounds(fieldX, y2, 120, fieldH);
        pnlFormulario.add(txtM);
        this.txtMonto = txtM;

        // Fila 2 — Período
        lblPeriodo = makeLabel("Período:");
        lblPeriodo.setBounds(330, y2, 120, fieldH);
        pnlFormulario.add(lblPeriodo);

        JTextField txtP = new JTextField();
        txtP.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        txtP.setToolTipText("Ej: Junio 2026");
        txtP.setBounds(455, y2, 200, fieldH);
        pnlFormulario.add(txtP);
        this.txtPeriodo = txtP;

        // Fila 3 — Estado
        int y3 = y2 + rowH;
        lblEstado = makeLabel("Estado:");
        lblEstado.setBounds(labelX, y3, labelW, fieldH);
        pnlFormulario.add(lblEstado);

        comboEstado = new JComboBox<>(new String[]{"Pendiente", "Pagado", "Atrasado"});
        comboEstado.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        comboEstado.setBounds(fieldX, y3, 150, fieldH);
        pnlFormulario.add(comboEstado);

        // Fila 3 — Forma de pago
        lblFormaPago = makeLabel("Forma de Pago:");
        lblFormaPago.setBounds(330, y3, 120, fieldH);
        pnlFormulario.add(lblFormaPago);

        comboFormaPago = new JComboBox<>(new String[]{"Efectivo", "Transferencia", "Depósito"});
        comboFormaPago.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        comboFormaPago.setBounds(455, y3, 150, fieldH);
        pnlFormulario.add(comboFormaPago);

        // ── Botones ───────────────────────────────────────────────
        int y4 = y3 + rowH + 10;

        btnGuardar = makeButton("Guardar", new Color(0, 0, 0), Color.WHITE);
        btnGuardar.setBounds(fieldX, y4, 130, 32);
        pnlFormulario.add(btnGuardar);

        btnRegresar = makeButton("← Regresar", new Color(90, 90, 90), Color.WHITE);
        btnRegresar.setBounds(fieldX + 150, y4, 130, 32);
        pnlFormulario.add(btnRegresar);

        // ── Tabla de alícuotas registradas ────────────────────────
        JLabel lblHistorial = new JLabel("Historial de Alícuotas");
        lblHistorial.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblHistorial.setBounds(15, 295, 250, 25);
        pnlPrincipal.add(lblHistorial);

        tablaAlicuotas = new JTable();
        tablaAlicuotas.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        tablaAlicuotas.setRowHeight(22);
        tablaAlicuotas.setSelectionBackground(new Color(200, 220, 255));
        tablaAlicuotas.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        tablaAlicuotas.getTableHeader().setBackground(Color.WHITE);
        tablaAlicuotas.getTableHeader().setForeground(Color.BLACK);
        tablaAlicuotas.setEnabled(false);

        scrollTabla = new JScrollPane(tablaAlicuotas);
        scrollTabla.setBounds(15, 325, 745, 255);
        pnlPrincipal.add(scrollTabla);

        getContentPane().add(pnlPrincipal);
        pack();
        setSize(780, 630);
    }

    private void inicializarTabla() {
        modeloTabla = new DefaultTableModel(
            new String[]{"Casa", "Residente", "Monto ($)", "Período", "Estado", "Forma de Pago", "Fecha de Registro"}, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };
        tablaAlicuotas.setModel(modeloTabla);
    }

    // ── Helpers UI ────────────────────────────────────────────────
    private JLabel makeLabel(String texto) {
        JLabel l = new JLabel(texto);
        l.setFont(new Font("Segoe UI", Font.BOLD, 13));
        return l;
    }

    private JButton makeButton(String texto, Color bg, Color fg) {
        JButton b = new JButton(texto);
        b.setBackground(bg);
        b.setForeground(fg);
        b.setFont(new Font("Segoe UI", Font.BOLD, 13));
        b.setFocusPainted(false);
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return b;
    }

    // ── Implementación de interfaz_alicuotas ──────────────────────

    @Override
    public String getNumeroCasa() {
        Object sel = comboCasa.getSelectedItem();
        return sel != null ? sel.toString() : "";
    }

    @Override
    public String getNombreResidente() {
        return txtResidente.getText();
    }

    @Override
    public void setNombreResidente(String nombre) {
        txtResidente.setText(nombre);
    }

    @Override
    public double getMonto() {
        return Double.parseDouble(txtMonto.getText().trim().replace(",", "."));
    }

    @Override
    public String getPeriodo() {
        return txtPeriodo.getText();
    }

    @Override
    public String getEstado() {
        return (String) comboEstado.getSelectedItem();
    }

    @Override
    public String getFormaPago() {
        return (String) comboFormaPago.getSelectedItem();
    }

    @Override
    public JButton getBtnGuardar()   { return btnGuardar;  }

    @Override
    public JButton getBtnRegresar()  { return btnRegresar; }

    @Override
    public JComboBox<String> getComboCasa() { return comboCasa; }

    @Override
    public void mostrarMensaje(String msg) {
        JOptionPane.showMessageDialog(this, msg);
    }

    @Override
    public void limpiarCampos() {
        comboCasa.setSelectedIndex(0);
        txtResidente.setText("");
        txtMonto.setText("");
        txtPeriodo.setText("");
        comboEstado.setSelectedIndex(0);
        comboFormaPago.setSelectedIndex(0);
    }

    @Override
    public void actualizarTabla(ArrayList<Alicuota> lista) {
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
        modeloTabla.setRowCount(0);
        for (Alicuota a : lista) {
            String fecha = a.getFechaRegistro() != null
                    ? a.getFechaRegistro().format(fmt)
                    : "—";
            modeloTabla.addRow(new Object[]{
                a.getNumeroCasa(),
                a.getNombreResidente(),
                String.format("%.2f", a.getMonto()),
                a.getPeriodo(),
                a.getEstado(),
                a.getFormaPago(),
                fecha
            });
        }
    }

    @Override
    public void iniciar() {
        this.setVisible(true);
    }
}
