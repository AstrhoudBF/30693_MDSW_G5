package Vista;

import Controlador.controlador_arriendos;
import Controlador.controlador_arriendos_sede;
import javax.swing.*;
import java.awt.*;

/**
 * Diálogo intermedio que aparece al hacer clic en "Arriendos" en el menú.
 * Permite elegir entre:
 *   - Locales / Parqueaderos (contrato mensual)
 *   - Sede Social (reserva por horas o día)
 *   - Ver Historial General
 */
public class Dialogo_Selector_Arriendo extends JDialog {

    private final JFrame menuPadre;

    public Dialogo_Selector_Arriendo(JFrame padre) {
        super(padre, "Módulo de Arriendos", true); // modal
        this.menuPadre = padre;
        initComponents();
    }

    private void initComponents() {
        setSize(420, 300);
        setLocationRelativeTo(menuPadre);
        setResizable(false);

        JPanel pnl = new JPanel(null);
        pnl.setBackground(Color.WHITE);
        getContentPane().add(pnl);

        // ── Título ────────────────────────────────────────────────
        JLabel lblTit = new JLabel("¿Qué desea gestionar?");
        lblTit.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblTit.setBounds(20, 18, 380, 28);
        pnl.add(lblTit);

        JLabel lblSub = new JLabel("Seleccione el tipo de arriendo:");
        lblSub.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lblSub.setBounds(20, 48, 380, 20);
        pnl.add(lblSub);

        // ── Botón: Locales y Parqueaderos ─────────────────────────
        JButton btnLocales = makeBigButton(
            "🏪  Locales y Parqueaderos",
            "Contratos mensuales para locales comerciales\ny espacios de parqueadero.",
            new Color(220, 240, 255), new Color(30, 80, 160)
        );
        btnLocales.setBounds(20, 82, 375, 60);
        btnLocales.addActionListener(e -> abrirLocalesParqueaderos());
        pnl.add(btnLocales);

        // ── Botón: Sede Social ────────────────────────────────────
        JButton btnSede = makeBigButton(
            "🏛  Sede Social",
            "Reservas por horas o día completo.\nValidación automática de choques de fechas.",
            new Color(255, 240, 210), new Color(140, 80, 0)
        );
        btnSede.setBounds(20, 154, 375, 60);
        btnSede.addActionListener(e -> abrirSedeSocial());
        pnl.add(btnSede);

        // ── Botón: Historial ──────────────────────────────────────
        JButton btnHist = new JButton("📊  Ver Historial y Totales Recaudados");
        btnHist.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnHist.setBackground(new Color(240, 240, 240));
        btnHist.setForeground(new Color(50, 50, 50));
        btnHist.setFocusPainted(false);
        btnHist.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnHist.setBounds(20, 226, 375, 35);
        btnHist.addActionListener(e -> {
            new Formulario_Historial_Arriendos().setVisible(true);
        });
        pnl.add(btnHist);
    }

    private void abrirLocalesParqueaderos() {
        dispose();
        interfaz_arriendos vista = new Formulario_Arriendos();
        controlador_arriendos ctrl = new controlador_arriendos(vista);
        ctrl.iniciar();
        menuPadre.dispose();
    }

    private void abrirSedeSocial() {
        dispose();
        interfaz_arriendos_sede vista = new Formulario_Arriendos_Sede();
        controlador_arriendos_sede ctrl = new controlador_arriendos_sede(vista);
        ctrl.iniciar();
        menuPadre.dispose();
    }

    private JButton makeBigButton(String titulo, String descripcion, Color bg, Color fgTit) {
        JButton b = new JButton();
        b.setLayout(new BorderLayout(8, 2));
        b.setBackground(bg);
        b.setFocusPainted(false);
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(bg.darker(), 1),
            BorderFactory.createEmptyBorder(6, 12, 6, 12)
        ));

        JLabel lTit = new JLabel(titulo);
        lTit.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lTit.setForeground(fgTit);

        JLabel lDesc = new JLabel("<html>" + descripcion.replace("\n", "<br>") + "</html>");
        lDesc.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        lDesc.setForeground(new Color(80, 80, 80));

        JPanel inner = new JPanel(new BorderLayout(0, 2));
        inner.setOpaque(false);
        inner.add(lTit, BorderLayout.NORTH);
        inner.add(lDesc, BorderLayout.CENTER);

        b.add(inner, BorderLayout.CENTER);
        return b;
    }
}
