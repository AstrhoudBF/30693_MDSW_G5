package Vista;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import java.util.ArrayList;
import Modelo.Alicuota;

public interface interfaz_alicuotas {

    // ── Getters de campos ─────────────────────────────────────────
    String getNumeroCasa();
    String getNombreResidente();
    double getMonto();
    String getPeriodo();
    String getEstado();
    String getFormaPago();

    // ── Setter para mostrar el residente automáticamente ──────────
    void setNombreResidente(String nombre);

    // ── Botones ───────────────────────────────────────────────────
    JButton getBtnGuardar();
    JButton getBtnRegresar();
    JComboBox<String> getComboCasa();

    // ── Utilidades de UI ──────────────────────────────────────────
    void mostrarMensaje(String msg);
    void limpiarCampos();
    void actualizarTabla(ArrayList<Alicuota> lista);
    void iniciar();
    void dispose();
}
