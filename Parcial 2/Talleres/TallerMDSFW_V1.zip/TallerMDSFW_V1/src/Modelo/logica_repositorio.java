
package Modelo;

public class logica_repositorio {

    private Datos datos;

    public logica_repositorio(Datos datos) {
        this.datos = datos;
    }

    // Verificar si existe un ID
   public boolean existeId(String id) {
    for (Estudiante e : datos.getLista_estudiantes()) {
        if (e.getId().equals(id)) {  // == → .equals()
            return true;
        }
    }
    return false;
}

    // Buscar estudiante por ID
   public Estudiante buscarPorId(String id) {
    for (Estudiante e : datos.getLista_estudiantes()) {
        if (e.getId().equals(id)) {  // == → .equals()
            return e;
        }
    }
    return null;
}

    // Validar nombre
    public boolean validarNombre(String nombre) {

        return nombre.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ ]+");
    }

    // Validar apellido
    public boolean validarApellido(String apellido) {

        return apellido.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ ]+");
    }

    // Validar edad
    public boolean validarEdad(int edad) {

        return edad >= 18 && edad <= 30;
    }

    // Validar ID de 5 dígitos
    public boolean validarId(String id) {
    return id.matches("[a-zA-Z0-9]{5}");  
}

}