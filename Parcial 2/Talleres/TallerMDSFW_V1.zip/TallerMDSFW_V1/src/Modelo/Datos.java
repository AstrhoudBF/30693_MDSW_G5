
package Modelo;
import java.util.ArrayList;

public class Datos {
    
    public ArrayList<Estudiante> lista_estudiantes = new ArrayList<>();
    public void agregarEstudiante(Estudiante e) {
        lista_estudiantes.add(e);
    }
    public ArrayList<Estudiante> getLista_estudiantes() {
        return lista_estudiantes;
    }
}
