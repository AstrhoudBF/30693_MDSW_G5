
package Vista;

import javax.swing.JButton;
import javax.swing.JTable;

public interface interfaz_estudiante {

    JButton getBtnAgregar();
    void limpiarCampos();

    JButton getBtnActualizar();
    JButton getBtnEliminar();
    JButton getBtnMostrar();
    String getId();
    String getNombre();
    String getApellido();
    int getEdad();
    JTable getTablaEstudiantes();
} 
    
