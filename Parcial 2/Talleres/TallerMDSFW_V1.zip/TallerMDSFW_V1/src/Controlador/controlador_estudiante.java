package Controlador;

import Modelo.Datos;
import Modelo.Estudiante;
import Modelo.logica_repositorio;
import Vista.interfaz_estudiante;
import javax.swing.table.DefaultTableModel;
import javax.swing.JOptionPane;

public class controlador_estudiante {

    private interfaz_estudiante ver;
    private Datos datos;
    private logica_repositorio logica;

    DefaultTableModel modeloTabla =
            new DefaultTableModel();

    // CONSTRUCTOR
    public controlador_estudiante(
        interfaz_estudiante ver,
        Datos datos) {

    this.ver = ver;
    this.datos = datos;
    this.logica = new logica_repositorio(datos);

    modeloTabla.addColumn("ID");
    modeloTabla.addColumn("Nombre");
    modeloTabla.addColumn("Apellido");
    modeloTabla.addColumn("Edad");

    this.ver.getTablaEstudiantes()
            .setModel(modeloTabla);

    this.ver.getBtnAgregar()
            .addActionListener(e -> agregar());

    this.ver.getBtnActualizar()
            .addActionListener(e -> actualizar());

    this.ver.getBtnEliminar()
            .addActionListener(e -> eliminar());

    this.ver.getBtnMostrar()
            .addActionListener(e -> mostrarTabla());
}
    
public void agregar() {

    String nombre = ver.getNombre().trim();
    String apellido = ver.getApellido().trim();

    String id = ver.getId();
    int edad = ver.getEdad();
    
    if(id.isEmpty()){

    JOptionPane.showMessageDialog(
            null,
            "No se pueden guardar los datos si existen campos vacíos.");

    return;
}
    

    if(nombre.isEmpty() || apellido.isEmpty()){

        JOptionPane.showMessageDialog(
                null,
                "Todos los campos son obligatorios");

        return;
    }

    if(!logica.validarNombre(nombre)){

        JOptionPane.showMessageDialog(
                null,
                "No se puede ingresar números ni caracteres especiales en el nombre");

        return;
    }

    if(!logica.validarApellido(apellido)){

        JOptionPane.showMessageDialog(
                null,
                "No se puede ingresar números ni caracteres especiales en el apellido");

        return;
    }

    if(!logica.validarId(id)){

        JOptionPane.showMessageDialog(
                null,
                "El ID debe tener 5 dígitos");

        return;
    }

    if(!logica.validarEdad(edad)){

        JOptionPane.showMessageDialog(
                null,
                "La edad debe estar entre 18 y 30");

        return;
    }

    if(logica.existeId(id)){

        JOptionPane.showMessageDialog(
                null,
                "El ID ya existe");

        return;
    }

    Estudiante estudiante =
            new Estudiante(
                    id,
                    nombre,
                    apellido,
                    edad);

    datos.agregarEstudiante(estudiante);

    ver.limpiarCampos();

    JOptionPane.showMessageDialog(
            null,
            "Datos guardados correctamente");
    
   
}

public void actualizar() {

    String textoId =
            JOptionPane.showInputDialog(
                    null,
                    "Ingrese ID del estudiante");

    if(textoId == null){
        return;
    }

    if(!textoId.matches("[a-zA-Z0-9]{5}")){

        JOptionPane.showMessageDialog(
                null,
                "ID inválido");

        return;
    }

    Estudiante estudiante =
            logica.buscarPorId(textoId);  // <-- era buscarPorId(id), corregido

    if(estudiante == null){

        JOptionPane.showMessageDialog(
                null,
                "ID no encontrado");

        return;
    }

    modeloTabla.setRowCount(0);

    modeloTabla.addRow(new Object[]{
        estudiante.getId(),
        estudiante.getNombre(),
        estudiante.getApellido(),
        estudiante.getEdad()
    });

    String nombre =
            JOptionPane.showInputDialog(
                    "Nuevo nombre",
                    estudiante.getNombre());

    if(nombre == null) return;  // si cancela

    String apellido =
            JOptionPane.showInputDialog(
                    "Nuevo apellido",
                    estudiante.getApellido());

    if(apellido == null) return;  // si cancela

    String edadTexto =
            JOptionPane.showInputDialog(
                    "Nueva edad",
                    estudiante.getEdad());

    if(edadTexto == null) return;  // si cancela

    int edad;
    try {
        edad = Integer.parseInt(edadTexto);
    } catch(NumberFormatException e){
        JOptionPane.showMessageDialog(
                null,
                "La edad debe ser un número válido");
        return;
    }

    if(!logica.validarNombre(nombre)
            || !logica.validarApellido(apellido)
            || !logica.validarEdad(edad)){

        JOptionPane.showMessageDialog(
                null,
                "Datos inválidos");

        return;
    }

    estudiante.setNombre(nombre);
    estudiante.setApellido(apellido);
    estudiante.setEdad(edad);

    mostrarTabla();

    ver.limpiarCampos();

    JOptionPane.showMessageDialog(
            null,
            "Datos actualizados");
}

public void eliminar() {

    String textoId =
            JOptionPane.showInputDialog(
                    null,
                    "Ingrese ID del estudiante");

    if(textoId == null){
        return;
    }

    if(!textoId.matches("[a-zA-Z0-9]{5}")){  // <-- era \\d{5}

        JOptionPane.showMessageDialog(
                null,
                "ID inválido");

        return;
    }

    // <-- era: int id = Integer.parseInt(textoId); (ERROR)
    Estudiante estudiante =
            logica.buscarPorId(textoId);  // <-- directo con textoId

    if(estudiante == null){

        JOptionPane.showMessageDialog(
                null,
                "ID no encontrado");

        return;
    }

    int opcion =
        JOptionPane.showConfirmDialog(
                null,
                "¿Está seguro de eliminar al estudiante "
                + estudiante.getNombre()
                + " "
                + estudiante.getApellido()
                + "?",
                "Confirmar eliminación",
                JOptionPane.YES_NO_OPTION);

    if(opcion == JOptionPane.YES_OPTION){

        datos.getLista_estudiantes()
                .remove(estudiante);

        mostrarTabla();

        ver.limpiarCampos();

        JOptionPane.showMessageDialog(
                null,
                "Estudiante eliminado");
    }
}
    // MOSTRAR TABLA
public void mostrarTabla() {

    modeloTabla.setRowCount(0);

    for(Estudiante e :
            datos.getLista_estudiantes()) {

        modeloTabla.addRow(
                new Object[]{
                    e.getId(),
                    e.getNombre(),
                    e.getApellido(),
                    e.getEdad()
                });
    }
}
} 
